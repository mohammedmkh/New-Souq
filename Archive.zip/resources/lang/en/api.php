<?php

return [
    'success' => '  تم تنفيذ الامر بنجاح ',
    'wrong_login'   => 'خطأ في البيانات المدخلة',
    'success_login' => 'تم تسجيل الدخول بنجاح',
];
